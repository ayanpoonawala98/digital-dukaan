import { Op } from 'sequelize';
import { sequelize, Business, User, Category, Product, Lead, PushSubscription, RestaurantOrder, Coupon, Referral } from './models/index.js';
import { unregisterStoreDomain } from './utils/store-domain.js';

export const RESTORE_MS = 30 * 24 * 60 * 60 * 1000;
export const restoreDeadline = deletedAt => new Date(new Date(deletedAt).getTime() + RESTORE_MS);

// Bounded batch so a normal day's expirations do not form a multi-day backlog.
// Domain detach happens only once restoration is forbidden. If the DB transaction
// fails, the tombstone remains offline and a later run retries (404 detach is OK).
export async function purgeExpiredStore(now = new Date()) {
  const cutoff = new Date(now.getTime() - RESTORE_MS);
  const stores = await Business.findAll({ where: { deletedAt: { [Op.lte]: cutoff } }, order: [['deletedAt', 'ASC']], limit: 25 });
  let purged = 0;
  for (const store of stores) {
    await unregisterStoreDomain(store.slug);
    await sequelize.transaction(async transaction => {
      const options = { where: { businessId: store.id }, transaction };
      for (const Model of [PushSubscription, RestaurantOrder, Coupon, Referral, Lead, Product]) await Model.destroy(options);
      await Category.destroy(options);
      await User.destroy({ where: { role: 'staff', staffBusinessId: store.id }, transaction });
      await store.destroy({ transaction });
    });
    purged++;
  }
  return { purged, hasMore: stores.length === 25 };
}
